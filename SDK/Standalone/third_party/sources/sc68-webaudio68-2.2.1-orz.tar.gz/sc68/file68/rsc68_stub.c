/**
 * rsc68_stub.c — sc68 资源管理存根
 *
 * 为原生编译提供空的 SC68rsc_* 实现。
 * sc68 资源管理（插件加载/配置读写）在嵌入式场景中不需要。
 */
#include <stddef.h>
#include "config68.h"
#include "file68/rsc68.h"
#include "file68/istream68.h"

const char * SC68rsc_set_share(const char *path) {
    (void)path;
    return NULL;
}

const char * SC68rsc_set_user(const char *path) {
    (void)path;
    return NULL;
}

void SC68rsc_get_path(const char **share, const char **user) {
    if (share) *share = NULL;
    if (user) *user = NULL;
}

istream_t * SC68rsc_open(SC68rsc_t type, const char *name, int mode) {
    (void)type;
    (void)name;
    (void)mode;
    return NULL;
}
